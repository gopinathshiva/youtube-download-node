<?php
//homepage images
td_demo_media::add_image_to_media_gallery('td_pic_1',                   "http://demo_content.tagdiv.com/Newspaper_6/default/1.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_2',                   "http://demo_content.tagdiv.com/Newspaper_6/default/2.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_3',                   "http://demo_content.tagdiv.com/Newspaper_6/default/3.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_4',                   "http://demo_content.tagdiv.com/Newspaper_6/default/4.jpg");








