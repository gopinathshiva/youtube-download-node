<?php

// ads
td_demo_media::add_image_to_media_gallery('td_wedding_smartlist_ad',            "http://demo_content.tagdiv.com/Newspaper_6/wedding/banner-smartlist.jpg");
td_demo_media::add_image_to_media_gallery('td_wedding_sidebar_ad',              "http://demo_content.tagdiv.com/Newspaper_6/wedding/banner-sidebar.jpg");
td_demo_media::add_image_to_media_gallery('td_homepage_big_ad',                 "http://demo_content.tagdiv.com/Newspaper_6/wedding/big-ad.jpg");